#ifndef CONFIGRATIONS_H
#define CONFIGRATIONS_H

#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <string>
#include <stdio.h>
#include <filesystem>
#include <fstream>
#include <ctime>
#include <vector>


enum class Std_Return : unsigned char{
    STD_R_NOK,
    STD_R_OK
};

#endif
