#ifndef COMMENT_H
#define COMMENT_H

#include "../../configrations.hpp"
#include "../Led/led.hpp"

class Command {
    public:
    Std_Return executeCmdLine(std::string commaned);
    private:

};

#endif